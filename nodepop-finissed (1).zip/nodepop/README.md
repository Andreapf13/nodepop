# NodePoP

## Requisitos
MongoDb instalado con base de datos `nodepop` y collección `advertisements` en localhost puerto 27017.

## Instalación

```bash
    npm install --secure
```

## Inicio del programa

```bash
    npm start
```

## Inicializar la base de datos

```bach
    npm run init
```

Borra los datos de la collección `nodepop.advertisements` e inserta estos anuncios:

```json
{
    "anuncios": [
        {
            "nombre": "Bicicleta",
            "venta": true,
            "precio": 230.15,
            "foto": "bici.jpg",
            "tags": [
                "lifestyle",
                "motor"
            ]
        },
        {
            "nombre": "iPhone 3GS",
            "venta": false,
            "precio": 50.00,
            "foto": "iphone.png",
            "tags": [
                "lifestyle",
                "mobile"
            ]
        }
    ]
}
```

## Configuración por defecto

* Puerto: 3000
* Precio máximo: 1000000
* Precio mínimo: 0
* MongoDb host: localhost
* MongoDB port: 27017
* MongoDb database: nodepop
* MongoDb collectios: advertisements

## Comandos

### GET Anuncios
Request:
```http
http://localhost:3000/apiv1/advertisements
```
Response:

```json
[
    {
        "_id": "63a08e10e4db33546f690065",
        "nombre": "Bicicleta",
        "venta": true,
        "precio": 230.15,
        "foto": "bici.jpg",
        "tags": [
            "lifestyle",
            "motor"
        ]
    },
    {
        "_id": "63a08e5be4db33546f690066",
        "nombre": "iPhone 3GS",
        "venta": false,
        "precio": 50,
        "foto": "iphone.png",
        "tags": [
            "lifestyle",
            "mobile"
        ]
    }
]
```

#### Filtro **nombre**
Request:
```http
http://localhost:3000/apiv1/advertisements?nombre=Bic
```
Response:
```json
[
    {
        "_id": "63a08e10e4db33546f690065",
        "nombre": "Bicicleta",
        "venta": true,
        "precio": 230.15,
        "foto": "bici.jpg",
        "tags": [
            "lifestyle",
            "motor"
        ]
    }
]
```

#### Filtro **tags**
Request:
```http
http://localhost:3000/apiv1/advertisements?tags=lifestyle,mobile
```
Response:
```json
[
    {
        "_id": "63a08e10e4db33546f690065",
        "nombre": "Bicicleta",
        "venta": true,
        "precio": 230.15,
        "foto": "bici.jpg",
        "tags": [
            "lifestyle",
            "motor"
        ]
    },
    {
        "_id": "63a08e5be4db33546f690066",
        "nombre": "iPhone 3GS",
        "venta": false,
        "precio": 50,
        "foto": "iphone.png",
        "tags": [
            "lifestyle",
            "mobile"
        ]
    }
]
```

#### Filtro **precioMin** y **precioMax**
Request:
```http
http://localhost:3000/apiv1/advertisements?precioMin=200&precioMax=300
```
Response:
```json
[
    {
        "_id": "63a08e10e4db33546f690065",
        "nombre": "Bicicleta",
        "venta": true,
        "precio": 230.15,
        "foto": "bici.jpg",
        "tags": [
            "lifestyle",
            "motor"
        ]
    }
]
```
#### Filtro **venta**
Request:
```http
http://localhost:3000/apiv1/advertisements?venta=false
```
Response:
```json
[
    {
        "_id": "63a08e5be4db33546f690066",
        "nombre": "iPhone 3GS",
        "venta": false,
        "precio": 50,
        "foto": "iphone.png",
        "tags": [
            "lifestyle",
            "mobile"
        ]
    }
]
```
#### Observaciones
Todos los filtros existentes pueden funcionar en conjunto:
Request
```http
http://localhost:3000/apiv1/advertisements?nombre=iPh&venta=false&precioMin=20&tags=lifestyle
```
Response:
```json
[
    {
        "_id": "63a08e5be4db33546f690066",
        "nombre": "iPhone 3GS",
        "venta": false,
        "precio": 50,
        "foto": "iphone.png",
        "tags": [
            "lifestyle",
            "mobile"
        ]
    }
]
```
### GET Anuncio por ID
Request:

```http
http://localhost:3000/apiv1/advertisements/63a08e10e4db33546f690065
```

Response:

```json
{
    "_id": "63a08e10e4db33546f690065",
    "nombre": "Bicicleta",
    "venta": true,
    "precio": 230.15,
    "foto": "bici.jpg",
    "tags": [
        "lifestyle",
        "motor"
    ]
}
```

### GET tags existentes

Reques:
```http
http://localhost:3000/apiv1/advertisements/tags
```
Response:
```json
{
    "tags": [
        "lifestyle",
        "motor",
        "mobile",
        "work"
    ]
}
```

### POST Anuncio

```http
http://localhost:3000/apiv1/advertisements
```

````body
{
  "nombre": "Notebook",
  "venta": false,
  "precio": 10,
  "foto": "notebook.png",
  "tags": [
    "work"
  ]
}
```

Response:
```json
{
    "nombre": "Notebook",
    "venta": false,
    "precio": 10,
    "foto": "notebook.png",
    "tags": [
        "work"
    ],
    "_id": "63a183024fb236a5fba47eb9",
    "__v": 0
}
```