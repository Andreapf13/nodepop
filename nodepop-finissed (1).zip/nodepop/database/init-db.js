const mongoose = require('mongoose');
const advertisements = require('../models/advertisements');
const data = require('./anuncios.json');
const mongoURI = "mongodb://localhost:27017/nodepop";

mongoose.set('strictQuery', false);

mongoose
    .connect(mongoURI)
    .then(async () => {
        console.log("Connection opened!")
        console.log("Initialling MongoDB's collection called advertisements ")
        await advertisements.deleteMany();
        await advertisements.insertMany(data.anuncios);
        console.log("Success!")
    })
    .catch((error) => console.error(error))
    .finally(async () => {
        await mongoose.connection.close()
        console.log("Connection clossed!")
    });