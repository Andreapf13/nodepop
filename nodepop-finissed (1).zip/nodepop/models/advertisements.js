const mongoose = require('mongoose');

const advertisementsSchema = mongoose.Schema({
    nombre: {
        type: String,
        required: true
    },
    venta: {
        type: Boolean,
        required: true
    },
    precio:{
        type: Number,
        required: true,
        min: 0,
        max: 1000000
    },
    foto:{
        type: String,
        required: true
    },
    tags: {
        type: Array,
        required: true
    }
});

module.exports = mongoose.model('advertisements', advertisementsSchema);