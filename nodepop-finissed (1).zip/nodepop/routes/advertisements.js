var express = require('express');
var router = express.Router();
const advertisementsSchema = require("../models/advertisements")

///Esta función recibe los query y prepara los filtros para Mongo.
const loadMongoFilters = ({
  nombre,
  precioMax,
  precioMin,
  tags,
  venta
}) => ({
  ...(nombre ? { nombre: new RegExp('^' + nombre + '.*', "i") } : {}),
  ...((precioMax || precioMin) ? { precio: { '$gte': precioMin || 0, '$lte': precioMax || 1000000 } } : {}),
  ...(tags ? { tags: { '$in': tags.split(',') } } : {}),
  ...(venta ? { venta } : {})
});

/* GET advertisements listing. */
router.get('/', function (req, res, next) {
  advertisementsSchema
    .find(loadMongoFilters(req.query))
    .then(data => res.status(200).json(data))
    .catch(err => res.status(202).json({ msg: err }));
});


/* GET exist tags. */
router.get('/tags', function (req, res, next) {
  advertisementsSchema
    .find({}, 'tags')
    .then(data => {
      // Unimos y filtramos los tags existentes en un mismo array.
      const tags = data
        .map(e => e.tags.toString())
        .toString()
        .split(',')
        .reduce((acc, item) => {
          if (!acc.includes(item)) {
            acc.push(item);
          }
          return acc;
        }, []);
      res.status(200).json({ tags })
    })
    .catch(err => res.status(202).json({ msg: err }));
});

/* GET advertisement by id. */
router.get('/:id', function (req, res, next) {
  const { id } = req.params;
  advertisementsSchema
    .findById(id)
    .then(data => res.status(200).json(data))
    .catch(err => res.status(202).json({ msg: err }));
});

/* POST Create advertisement. */
router.post('/', function (req, res, next) {
  const advertisement = advertisementsSchema(req.body);
  advertisement
    .save()
    .then(data => res.status(201).json(data))
    .catch(err => res.status(202).json({ msg: err }));
});

module.exports = router;
